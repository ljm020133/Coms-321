javac assignment2.java
