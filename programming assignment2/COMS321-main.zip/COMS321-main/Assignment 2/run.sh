java assignment2 $1
